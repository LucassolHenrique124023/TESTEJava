import pessoas.Aluno;
import pessoas.Pessoa;
//import java.util.*; //serve para importar todos os arquivos java
//import aulas.Diario;
//import pessoas.*; //o * serve para importar o arquivo todo


public class Aplicacao {

     public static void main(String[] args) {
        
        Pessoa pessoa = new Pessoa();
        String Dados = pessoa.exibirDados();
        System.out.print(Dados);

       // Aluno aluno = new Aluno();
       // String dados = aluno.exibirAluno();
       // System.out.println(dados);


     }
    }
