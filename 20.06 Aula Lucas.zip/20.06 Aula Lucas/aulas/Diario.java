package aulas;

public class Diario {
    
}
