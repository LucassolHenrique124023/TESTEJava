package pessoas;

public class Aluno extends Pessoa{
        //ATRIBUTOS
    public String Situacao;
    public double Media;
    public String Disciplina;   
    //METODOS
    protected String exibirSituacao(){
        return "Aprovado";
    }
    public double exibirMedia(){
        return 8.0;
    }
    public String exibirDisciplina(){
        return "Técnico";
    }
    public String exibirAluno(){
        return exibirDados()+" - "+exibirSituacao();
    }

}
