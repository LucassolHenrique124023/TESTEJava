package pessoas;

public class Professor extends Pessoa{
    
}
