package pessoas;

public class Pessoa {
    //atributos
    public String Nome;
    public int Idade;
    public String Email;

    
    private String exibirNome() {
        return "Lucas sol";
    }
     protected int exibirIdade() {
        return 18;
    }
     public String exibirDados() {
        return exibirNome()+" - "+exibirIdade();
    }
}
