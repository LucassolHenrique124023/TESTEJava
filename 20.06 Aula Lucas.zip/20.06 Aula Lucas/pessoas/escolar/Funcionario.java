package pessoas.escolar;

public class Funcionario {
    
}
